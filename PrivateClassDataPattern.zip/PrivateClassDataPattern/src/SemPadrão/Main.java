package SemPadrão;

public class Main {

    public static void main(String[] args) {
        System.out.println("=== Testando com o Padrão Private Class Data ===");

        // Cria um produto usando o padrão Private Class Data
        Produto produto = new Produto("Laptop", 2500.0);

        // Exibe informações do produto
        produto.exibirInfo();

        // Tenta acessar o nome e o preço
        System.out.println("Nome do produto (acesso direto): " + produto.getNome());
        System.out.println("Preço do produto (acesso direto): " + produto.getPreco());
    }
}
