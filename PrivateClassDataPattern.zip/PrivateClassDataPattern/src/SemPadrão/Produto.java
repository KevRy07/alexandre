package SemPadrão;

public class Produto {
    private String nome;
    private double preco;

    // Construtor para inicializar os dados
    public Produto(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
    }

    // Método que retorna o nome do produto
    public String getNome() {
        return nome;
    }

    // Método que retorna o preço do produto
    public double getPreco() {
        return preco;
    }

    // Método que imprime informações do produto
    public void exibirInfo() {
        System.out.println("Produto: " + getNome() + ", Preço: " + getPreco());
    }
}