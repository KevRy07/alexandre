package ComPadrão;

public class Produto {
    private DadosPrivados dados;

    // Construtor que cria uma instância de DadosPrivados
    public Produto(String nome, double preco) {
        this.dados = new DadosPrivados(nome, preco);
    }

    // Método que retorna o nome do produto usando DadosPrivados
    public String getNome() {
        return dados.getNome();
    }

    // Método que retorna o preço do produto usando DadosPrivados
    public double getPreco() {
        return dados.getPreco();
    }

    // Método que imprime informações do produto
    public void exibirInfo() {
        System.out.println("Produto: " + getNome() + ", Preço: " + getPreco());
    }
}
