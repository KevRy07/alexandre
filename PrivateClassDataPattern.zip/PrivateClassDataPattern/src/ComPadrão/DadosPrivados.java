package ComPadrão;

// Classe que armazena os dados privados de Produto
public class DadosPrivados {
    private String nome;
    private double preco;

    // Construtor para inicializar os dados
    public DadosPrivados(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
    }

    // Métodos para acessar os dados privados
    public String getNome() {
        return nome;
    }

    public double getPreco() {
        return preco;
    }
}
